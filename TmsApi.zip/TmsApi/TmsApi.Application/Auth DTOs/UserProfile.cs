public record LoginRequest(string Username, string Password)
{
    public string Email { get; set; }
}

public record UserProfileDto(string DisplayName, string Role);