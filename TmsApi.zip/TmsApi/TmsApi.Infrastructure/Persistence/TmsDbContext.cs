using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TmsApi.Domain.Entities;
using TmsApi.Infrastructure.Identity;

namespace TmsApi.Infrastructure.Persistence;

public class TmsDbContext : IdentityDbContext<TmsUser>
{
    public TmsDbContext(DbContextOptions<TmsDbContext> options)
        : base(options)
    {
    }

    // Existing TMS entities
    public DbSet<Student> Students => Set<Student>();

    public DbSet<Course> Courses => Set<Course>();

    public DbSet<Enrollment> Enrollments => Set<Enrollment>();

    // Refresh tokens
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();

    // public override async Task<int> SaveChangesAsync(
    //     CancellationToken cancellationToken = default)
    // {
    //     foreach (var entry in ChangeTracker.Entries())
    //     {
    //         if (entry.State == EntityState.Modified)
    //         {
    //             entry.Property("LastUpdated").CurrentValue =
    //                 DateTime.UtcNow;
    //         }
    //     }

    //     return await base.SaveChangesAsync(cancellationToken);
    // }
}