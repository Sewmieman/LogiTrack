using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureAppConfiguration((context, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Key"] =
                    "ThisIsASecretKeyForTestingPurposesOnly123456!",

                ["Jwt:Secret"] =
                    "ThisIsASecretKeyForTestingPurposesOnly123456!",

                ["Jwt:Issuer"] =
                    "TmsTestIssuer",

                ["Jwt:Audience"] =
                    "TmsTestAudience"
            });
        });
    }
}